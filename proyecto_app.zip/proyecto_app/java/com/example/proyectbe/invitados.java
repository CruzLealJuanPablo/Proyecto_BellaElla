package com.example.proyectbe;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.example.proyectbe.adapter.invAdapter;
import com.example.proyectbe.model.invitado;

public class invitados extends AppCompatActivity {

    FirebaseFirestore mFirestore;
    //mostrar registros
    RecyclerView mRecycler;
    invAdapter mAdapter;
    Query query;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invitados);

        mFirestore = FirebaseFirestore.getInstance();
        //referenciar
        mRecycler = findViewById(R.id.reciclerViewi);
        mRecycler.setLayoutManager(new LinearLayoutManager(invitados.this));

        //mostrar registros
        query = mFirestore.collection("Articulos").orderBy("Modelo",Query.Direction.ASCENDING);
        FirestoreRecyclerOptions<invitado> firestoreRecyclerOptions =
                new FirestoreRecyclerOptions.Builder<invitado>()
                        .setQuery(query, invitado.class).build();

        FirestoreRecyclerOptions<invitado> invitadosOptions =
                new FirestoreRecyclerOptions.Builder<invitado>().setQuery(query, invitado.class).build();

        mAdapter = new invAdapter(invitadosOptions,invitados.this,getSupportFragmentManager());

        mAdapter.notifyDataSetChanged();
        mRecycler.setAdapter(mAdapter);
    }
    @Override
    protected void onStop() {
        super.onStop();
        mAdapter.startListening();
    }
}
