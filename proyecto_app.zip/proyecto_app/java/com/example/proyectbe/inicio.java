package com.example.proyectbe;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.example.proyectbe.adapter.usuarioAdapter;
import com.example.proyectbe.model.usuario;
import android.app.AlertDialog;
import android.content.DialogInterface;

public class inicio extends AppCompatActivity {

    private Button btn_add, cerrarSes;
    FirebaseFirestore mFirestore;
    //mostrar registros
    RecyclerView mRecycler;
    usuarioAdapter mAdapter;
    Query query;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        mFirestore = FirebaseFirestore.getInstance();
        //referenciar
        mRecycler = findViewById(R.id.reciclerViewi);
        mRecycler.setLayoutManager(new LinearLayoutManager(this));

        //mostrar registros
        query = mFirestore.collection("Articulos").orderBy("Modelo",Query.Direction.ASCENDING);
        FirestoreRecyclerOptions<usuario> firestoreRecyclerOptions =
                new FirestoreRecyclerOptions.Builder<usuario>()
                        .setQuery(query, usuario.class).build();

        FirestoreRecyclerOptions<usuario> usuariosOptions =
                new FirestoreRecyclerOptions.Builder<usuario>().setQuery(query, usuario.class).build();

        mAdapter = new usuarioAdapter(usuariosOptions,this,getSupportFragmentManager());

        mAdapter.notifyDataSetChanged();
        mRecycler.setAdapter(mAdapter);

        btn_add = findViewById(R.id.btnAcceder);
        cerrarSes = findViewById(R.id.btnLogout);

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment1 cr = new fragment1();
                cr.show(getSupportFragmentManager(),
                        "Insertar Articulo");

                //fragment1 cr = new fragment1();
                //FragmentManager fragmentManager = getSupportFragmentManager();
                //FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                //fragmentTransaction.replace(R.id.frameLayout, cr);
                //fragmentTransaction.commit();

            }
        });

        cerrarSes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new AlertDialog.Builder(inicio.this)
                        .setTitle("Confirmar cierre de sesión")
                        .setMessage("¿Estás seguro de que deseas cerrar sesión?")
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                FirebaseAuth.getInstance().signOut();
                                Toast.makeText(inicio.this, "Sesión cerrada", Toast.LENGTH_SHORT).show();
                                Intent logout = new Intent(inicio.this, MainActivity.class);
                                startActivity(logout);
                                finish();
                            }
                        })
                        .setNegativeButton(android.R.string.no, null)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        mAdapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mAdapter.startListening();
    }
}
