package com.example.proyectbe;
import static android.app.Activity.RESULT_OK;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;

public class fragment1 extends DialogFragment {
    String id_user;
    private Button btn_add, cancelar;
    EditText nombre, descripcion, piezas, modelo;
    TextView titulo;
    CardView card;
    private StorageReference mStorage;
    private static final int GALLERY_INTENT = 1;
    private ProgressDialog progressDialog;

    FirebaseFirestore mfirestore = FirebaseFirestore.getInstance();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(getArguments()!=null){
            id_user= getArguments().getString("id_user");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_fragment1, container, false);
        mStorage = FirebaseStorage.getInstance().getReference();
        titulo = view.findViewById(R.id.lblTitulo);
        nombre = view.findViewById(R.id.txtTituloArt);
        descripcion = view.findViewById(R.id.txtDesc);
        piezas = view.findViewById(R.id.txtPiezas);
        modelo = view.findViewById(R.id.txtModelo);
        progressDialog = new ProgressDialog(getContext());

        cancelar = view.findViewById(R.id.btnCancelar);

        card = view.findViewById(R.id.cardView);

        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //OCULTAMOS EL FRAME Y VOLVEMOS AL CATALOGO
                card.setVisibility(View.GONE);
                getDialog().dismiss();
                //Intent abrircamara = new Intent(Intent.ACTION_PICK);
                //abrircamara.setType("image/*");
                //startActivityForResult(abrircamara,GALLERY_INTENT);
            }
        });

        btn_add = view.findViewById(R.id.btn_add);
        if(id_user== null || id_user=="") {
            btn_add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String Modelo = modelo.getText().toString().trim();
                    String Nombre = nombre.getText().toString().trim();
                    String Descripcion = descripcion.getText().toString().trim();
                    String Piezas = piezas.getText().toString().trim();

                    if (validaModelo(Modelo) && validaNombre(Nombre) && validaDescripcion(Descripcion) && validaPiezas(Piezas)) {
                        //OPCION PARA ENVIAR EL REGISTRO DE DATOS
                        enviarReg(Modelo, Nombre, Descripcion, Piezas);

                        //OCULTAMOS EL FRAME Y VOLVEMOS AL CATALOGO
                        card.setVisibility(View.GONE);
                        //getDialog().dismiss();
                    } else {
                        Toast.makeText(getContext(), "LLENAR TODOS LOS CAMPOS", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }else {
            getModel(id_user);
            titulo.setText("Editar Articulo");
            btn_add.setText("Actualizar");
            btn_add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String Modelo = modelo.getText().toString().trim();
                    String Nombre = nombre.getText().toString().trim();
                    String Descripcion = descripcion.getText().toString().trim();
                    String Piezas = piezas.getText().toString().trim();

                    if (validaModelo(Modelo) && validaNombre(Nombre) && validaDescripcion(Descripcion) && validaPiezas(Piezas)) {
                        //OPCION PARA EDITAR EL REGISTRO DE DATOS
                        updateReg(Modelo, Nombre, Descripcion, Piezas);

                        //OCULTAMOS EL FRAME Y VOLVEMOS AL CATALOGO
                        card.setVisibility(View.GONE);
                        //getDialog().dismiss();
                    } else {
                        Toast.makeText(getContext(), "ERROR AL ACTUALIZAR", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
        return view;
    }

    //////////////////////////////////// VALIDACION DE CAMPOS
    private boolean validaNombre(String Nombre) {
        return !Nombre.isEmpty();
    }
    private boolean validaDescripcion(String Descripcion) {
        return !Descripcion.isEmpty();
    }
    private boolean validaPiezas(String Piezas) {
        return Piezas.matches("[0-9]+");
    }
    private boolean validaModelo(String Modelo) { return !Modelo.isEmpty();}

////////////////////////////////////////////////////////////////////////////////////////////////////

    /////////////////////////////////////ENVIAR DATOS DE REGISTRO
    private void enviarReg(String Modelo, String Nombre, String Descripcion, String Piezas) {

        // Crear un mapa con los datos a enviar
        Map<String, Object> map1 = new HashMap<>();
        map1.put("Modelo", Modelo);
        map1.put("Nombre", Nombre);
        map1.put("Descripcion", Descripcion);
        map1.put("Piezas", Piezas);

        // Agregar los datos a Firestore
        mfirestore.collection("Articulos")
                .document(String.valueOf(Modelo))
                .set(map1)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        //OPCION PARA ABRIR LA GALERIA Y TRAER EL METODO
                        Intent abrircamara = new Intent(Intent.ACTION_PICK);
                        abrircamara.setType("image/*");
                        startActivityForResult(abrircamara,GALLERY_INTENT);

                        //Toast.makeText(getContext(), "Creado", Toast.LENGTH_SHORT).show();

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getContext(), "NO SE PUDO AGREGAR EL ARTICULO", Toast.LENGTH_SHORT).show();
                    }
                });
    }
////////////////////////////////////////////////////////////////////////////////////////////////////

    /////////////////////////////////ACTUALIZACION DE DATOS DE REGISTRO
    private void updateReg(String Modelo, String Nombre, String Descripcion, String Piezas){
        Map<String, Object> map2 = new HashMap<>();
        map2.put("Modelo", Modelo);
        map2.put("Nombre",Nombre);
        map2.put("Descripcion",Descripcion);
        map2.put("Piezas",Piezas);

        mfirestore.collection("Articulos")
                .document(id_user)//// Utiliza Matricula como ID del documento
                .update(map2).// asignan los datos del registro en el documento
                addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                //OPCION PARA ABRIR LA GALERIA Y TRAER EL METODO
                Intent abrircamara = new Intent(Intent.ACTION_PICK);
                abrircamara.setType("image/*");
                startActivityForResult(abrircamara,GALLERY_INTENT);

                //Toast.makeText(getContext(),"Actualizado Exitosamente", Toast.LENGTH_SHORT).show();

            }
        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getContext(),
                                "ERROR AL ACTUALIZAR", Toast.LENGTH_SHORT).show();
                    }
                });
    }
////////////////////////////////////////////////////////////////////////////////////////////////////

    ///////////////////////////////OBTENER DATOS DEL BOTON UPDATE
    private void getModel(String id_user){
        mfirestore.collection("Articulos")
                .document(id_user)//// Utiliza Matricula como ID del documento
                .get().// asignan los datos del registro en el documento
                addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                String Modelo = documentSnapshot.getString("Modelo");
                String Nombre = documentSnapshot.getString("Nombre");
                String Descripcion = documentSnapshot.getString("Descripcion");
                String Piezas = documentSnapshot.getString("Piezas");
                nombre.setText(Nombre);
                descripcion.setText(Descripcion);
                piezas.setText(Piezas);
                modelo.setText(Modelo);
            }
        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getContext(),
                                "ERROR AL OBTENER LOS DATOS", Toast.LENGTH_SHORT).show();
                    }
                });


    }
////////////////////////////////////////////////////////////////////////////////////////////////////

    ///////////////////////////METODO PARA SUBIR IMAGEN AL FIRESTORE
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == GALLERY_INTENT && resultCode == RESULT_OK){

            progressDialog.setTitle("Subiendo...");
            progressDialog.setMessage("Subiendo Imagen a la Base de Datos");
            progressDialog.setCancelable(false);
            progressDialog.show();

            String Modelo = modelo.getText().toString().trim();

            Uri uri = data.getData();
            StorageReference filepath = mStorage.child("Imagenes").child(Modelo);

            filepath.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    progressDialog.dismiss();
                    //Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                    //Uri descargarFoto = taskSnapshot.getDownloadUri();
                    //Glide.with(getContext())
                    //        .load(uriTask)
                    //        .fitCenter()
                    //        .centerCrop()
                    //        .into(img);

                    Toast.makeText(getContext(), "SE GUARDARON LOS DATOS", Toast.LENGTH_SHORT).show();
                    getDialog().dismiss();
                }
            });
        }
    }
////////////////////////////////////////////////////////////////////////////////////////////////////

}
