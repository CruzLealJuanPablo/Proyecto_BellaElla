package com.example.proyectbe.adapter;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.proyectbe.R;
import com.example.proyectbe.fragment1;
import com.example.proyectbe.model.usuario;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;

import android.app.Activity;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import android.app.AlertDialog;
import android.content.DialogInterface;

public class usuarioAdapter extends FirestoreRecyclerAdapter <usuario, usuarioAdapter.ViewHolder> {

    private FirebaseFirestore mFirestore = FirebaseFirestore.getInstance();
    Activity activity;
    FragmentManager fm;
    usuarioAdapter mAdapter;

    /**
     * Create a new RecyclerView adapter that listens to a Firestore Query.  See {@link
     * FirestoreRecyclerOptions} for configuration options.
     *
     * @param options
     */


    public usuarioAdapter(@NonNull FirestoreRecyclerOptions<usuario> options, Activity activity, FragmentManager fm) {
        super(options);
        this.activity = activity;
        this.fm = fm;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView art, desc, piezas;
        ImageView img;
        Button Eliminar, Editar;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            art = itemView.findViewById(R.id.txtNombre);
            desc = itemView.findViewById(R.id.txtDescripcion);
            piezas = itemView.findViewById(R.id.txtMPiezas);
            img = itemView.findViewById(R.id.imgArt);

            Eliminar = itemView.findViewById(R.id.btnEliminar);
            Editar = itemView.findViewById(R.id.btnEditar);
        }
    }

    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull usuario model) {
        DocumentSnapshot documentSnapshot = getSnapshots().getSnapshot(holder.getAdapterPosition());
        final String id = documentSnapshot.getId();

        holder.art.setText(model.getNombre());
        holder.desc.setText(model.getDescripcion());
        holder.piezas.setText(model.getPiezas());
        holder.img.setImageResource(model.getImg());

        holder.Editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment1 cr = new fragment1();
                Bundle bundle = new Bundle();
                bundle.putString("id_user", id);
                cr.setArguments(bundle);
                cr.show(fm, "fragment1");
            }
        });

        holder.Eliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(activity)
                        .setTitle("Confirmar eliminación")
                        .setMessage("¿Estás seguro de que deseas eliminar este elemento?")
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                delUser(id);
                            }
                        })
                        .setNegativeButton(android.R.string.no, null)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
            }
        });
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_usuario, parent, false);
        return new ViewHolder(v);
    }

    private void delUser(String id) {
        mFirestore.collection("Articulos")
                .document(id)
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(activity, "ELIMINADO CORRECTAMENTE", Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(activity, "ERROR AL ELIMINAR", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
