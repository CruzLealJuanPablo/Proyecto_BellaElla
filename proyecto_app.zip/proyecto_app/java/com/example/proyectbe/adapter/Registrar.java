package com.example.proyectbe.adapter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.proyectbe.MainActivity;
import com.example.proyectbe.R;

public class Registrar extends AppCompatActivity {
    Button registrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);

        registrar = findViewById(R.id.btnRegistrar);

        registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Validacion de datos
                Intent regs = new Intent(Registrar.this, MainActivity.class);
                startActivity(regs);
                finish();
                Toast.makeText(Registrar.this, "Usuario Registrado", Toast.LENGTH_SHORT).show();
            }
        });
    }
}